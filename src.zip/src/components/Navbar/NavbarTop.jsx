const NavbarTop = () => {
  return (
    <div>
      <h2>Topshiriq punktlari</h2>
    </div>
  );
};

export default NavbarTop;
