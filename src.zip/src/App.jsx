import "./App.css";
import NavbarMain from "./components/Navbar/NavbarMain";

function App() {
  return (
    <div className="App">
      <NavbarMain />
    </div>
  );
}

export default App;
